"""
Flask API — Emotion Sound Crisis Prediction System
REST API endpoints for file-based and live emotion/crisis prediction.
"""

import os
import json
import tempfile
from flask import Flask, request, jsonify, render_template
from werkzeug.utils import secure_filename

from utils.feature_extractor import extract_features
from utils.crisis_predictor import CrisisPredictor
from models.emotion_model import EmotionModel


app = Flask(__name__)
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024  # 16 MB max upload
ALLOWED_EXTENSIONS = {'wav', 'mp3', 'ogg', 'flac'}

# Load model once at startup
model = EmotionModel()
try:
    model.load('models/emotion_model')
    print("[✓] Model loaded successfully.")
except Exception as e:
    print(f"[!] Model not found — train first: {e}")

predictor = CrisisPredictor()


def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS


@app.route('/')
def index():
    return render_template('index.html')


@app.route('/predict', methods=['POST'])
def predict():
    """
    POST /predict
    Upload an audio file → returns emotion prediction and crisis score.
    """
    if 'audio' not in request.files:
        return jsonify({'error': 'No audio file provided.'}), 400

    file = request.files['audio']
    if file.filename == '' or not allowed_file(file.filename):
        return jsonify({'error': 'Invalid or unsupported file type.'}), 400

    filename = secure_filename(file.filename)
    with tempfile.NamedTemporaryFile(suffix=os.path.splitext(filename)[1], delete=False) as tmp:
        file.save(tmp.name)
        tmp_path = tmp.name

    try:
        features = extract_features(audio_path=tmp_path)
        emotion, confidence, probs = model.predict_emotion(features)
        result = predictor.rolling_score(emotion, confidence)
        result['probabilities'] = probs
        return jsonify(result)
    except Exception as e:
        return jsonify({'error': str(e)}), 500
    finally:
        os.unlink(tmp_path)


@app.route('/predict_text', methods=['POST'])
def predict_demo():
    """
    POST /predict_text
    Demo endpoint: accepts emotion name directly (for testing without audio).
    Body: { "emotion": "fearful", "confidence": 0.85 }
    """
    data = request.get_json()
    if not data or 'emotion' not in data:
        return jsonify({'error': 'Missing emotion field.'}), 400

    emotion = data.get('emotion', 'neutral')
    confidence = float(data.get('confidence', 0.75))
    result = predictor.rolling_score(emotion, confidence)
    return jsonify(result)


@app.route('/status', methods=['GET'])
def status():
    """GET /status — Health check and session alert count."""
    alerts = predictor.get_alert_summary()
    return jsonify({
        'status': 'running',
        'total_alerts': len(alerts),
        'crisis_alerts': sum(1 for a in alerts if a['risk_level'] == 'CRISIS'),
        'warning_alerts': sum(1 for a in alerts if a['risk_level'] == 'WARNING'),
    })


@app.route('/reset', methods=['POST'])
def reset():
    """POST /reset — Clear rolling window for new session."""
    predictor.reset()
    return jsonify({'status': 'reset successful'})


@app.route('/alerts', methods=['GET'])
def get_alerts():
    """GET /alerts — Return all session alerts."""
    return jsonify(predictor.get_alert_summary())


if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)
