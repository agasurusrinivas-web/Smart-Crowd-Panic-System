"""
Model Builder & Trainer — Emotion Sound Crisis Prediction System
Builds, trains, and saves the CNN+Dense emotion classifier.
"""

import os
import numpy as np
import pickle
from sklearn.preprocessing import LabelEncoder, StandardScaler
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report, confusion_matrix

try:
    import tensorflow as tf
    from tensorflow.keras.models import Sequential, load_model
    from tensorflow.keras.layers import Dense, Dropout, BatchNormalization, Conv1D, MaxPooling1D, Flatten, LSTM
    from tensorflow.keras.callbacks import EarlyStopping, ModelCheckpoint
    from tensorflow.keras.utils import to_categorical
    TF_AVAILABLE = True
except ImportError:
    TF_AVAILABLE = False
    print("[WARNING] TensorFlow not found. Using scikit-learn MLP fallback.")
    from sklearn.neural_network import MLPClassifier


EMOTIONS = ['neutral', 'calm', 'happy', 'sad', 'angry', 'fearful', 'disgust', 'surprised']
CRISIS_EMOTIONS = {'fearful', 'sad', 'disgust', 'angry'}  # emotions mapped to crisis risk

EMOTION_CRISIS_WEIGHTS = {
    'neutral':   0.0,
    'calm':      0.0,
    'happy':     0.0,
    'sad':       0.5,
    'angry':     0.4,
    'fearful':   0.9,
    'disgust':   0.6,
    'surprised': 0.2,
}


class EmotionModel:
    """Wrapper around the deep learning emotion classifier."""

    def __init__(self, input_dim=193, n_classes=8):
        self.input_dim = input_dim
        self.n_classes = n_classes
        self.model = None
        self.scaler = StandardScaler()
        self.label_encoder = LabelEncoder()
        self.label_encoder.fit(EMOTIONS)

    def build(self):
        """Build the neural network architecture."""
        if not TF_AVAILABLE:
            self.model = MLPClassifier(
                hidden_layer_sizes=(256, 128, 64),
                activation='relu',
                max_iter=500,
                random_state=42
            )
            return

        model = Sequential([
            Dense(256, activation='relu', input_shape=(self.input_dim,)),
            BatchNormalization(),
            Dropout(0.3),
            Dense(128, activation='relu'),
            BatchNormalization(),
            Dropout(0.3),
            Dense(64, activation='relu'),
            Dropout(0.2),
            Dense(self.n_classes, activation='softmax')
        ])

        model.compile(
            optimizer='adam',
            loss='categorical_crossentropy',
            metrics=['accuracy']
        )
        self.model = model
        print(model.summary())

    def train(self, X, y_labels, epochs=100, batch_size=32, val_split=0.2):
        """
        Train the model on extracted feature vectors.

        Args:
            X (np.ndarray): Feature matrix, shape (n_samples, 193)
            y_labels (list): String emotion labels per sample
            epochs (int): Training epochs
            batch_size (int): Mini-batch size
            val_split (float): Validation split fraction
        """
        X = self.scaler.fit_transform(X)
        y_enc = self.label_encoder.transform(y_labels)

        X_train, X_val, y_train, y_val = train_test_split(
            X, y_enc, test_size=val_split, random_state=42, stratify=y_enc
        )

        if not TF_AVAILABLE:
            self.model.fit(X_train, y_train)
            preds = self.model.predict(X_val)
            print(classification_report(y_val, preds, target_names=EMOTIONS))
            return

        y_train_cat = to_categorical(y_train, num_classes=self.n_classes)
        y_val_cat = to_categorical(y_val, num_classes=self.n_classes)

        callbacks = [
            EarlyStopping(patience=15, restore_best_weights=True),
            ModelCheckpoint('models/best_model.h5', save_best_only=True)
        ]

        history = self.model.fit(
            X_train, y_train_cat,
            validation_data=(X_val, y_val_cat),
            epochs=epochs,
            batch_size=batch_size,
            callbacks=callbacks,
            verbose=1
        )

        val_preds = np.argmax(self.model.predict(X_val), axis=1)
        print("\n--- Validation Report ---")
        print(classification_report(y_val, val_preds, target_names=EMOTIONS))
        return history

    def predict_emotion(self, feature_vector):
        """
        Predict emotion label from a single feature vector.

        Returns:
            tuple: (emotion_label, confidence_score, probabilities_dict)
        """
        x = self.scaler.transform([feature_vector])

        if not TF_AVAILABLE:
            pred = self.model.predict(x)[0]
            label = self.label_encoder.inverse_transform([pred])[0]
            return label, 1.0, {label: 1.0}

        probs = self.model.predict(x, verbose=0)[0]
        pred_idx = np.argmax(probs)
        label = self.label_encoder.inverse_transform([pred_idx])[0]
        prob_dict = {EMOTIONS[i]: float(probs[i]) for i in range(len(EMOTIONS))}
        return label, float(probs[pred_idx]), prob_dict

    def save(self, path='models/emotion_model'):
        """Save model and preprocessing objects."""
        os.makedirs(path, exist_ok=True)
        if TF_AVAILABLE:
            self.model.save(os.path.join(path, 'model.h5'))
        else:
            with open(os.path.join(path, 'model_sklearn.pkl'), 'wb') as f:
                pickle.dump(self.model, f)
        with open(os.path.join(path, 'scaler.pkl'), 'wb') as f:
            pickle.dump(self.scaler, f)
        print(f"[✓] Model saved to {path}")

    def load(self, path='models/emotion_model'):
        """Load saved model and preprocessing objects."""
        if TF_AVAILABLE:
            self.model = load_model(os.path.join(path, 'model.h5'))
        else:
            with open(os.path.join(path, 'model_sklearn.pkl'), 'rb') as f:
                self.model = pickle.load(f)
        with open(os.path.join(path, 'scaler.pkl'), 'rb') as f:
            self.scaler = pickle.load(f)
        print(f"[✓] Model loaded from {path}")
