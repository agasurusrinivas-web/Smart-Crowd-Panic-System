"""
Dataset Loader — Emotion Sound Crisis Prediction System
Loads RAVDESS and CREMA-D datasets, extracts features, and prepares training data.
"""

import os
import glob
import numpy as np
from tqdm import tqdm
from utils.feature_extractor import extract_features


# ─── RAVDESS emotion mapping (from filename code) ───────────────────────────
RAVDESS_EMOTIONS = {
    '01': 'neutral',
    '02': 'calm',
    '03': 'happy',
    '04': 'sad',
    '05': 'angry',
    '06': 'fearful',
    '07': 'disgust',
    '08': 'surprised',
}

# ─── CREMA-D emotion mapping (from filename suffix) ──────────────────────────
CREMAD_EMOTIONS = {
    'NEU': 'neutral',
    'HAP': 'happy',
    'SAD': 'sad',
    'ANG': 'angry',
    'FEA': 'fearful',
    'DIS': 'disgust',
}


def load_ravdess(data_dir: str):
    """
    Load RAVDESS dataset from directory.
    Expected structure: data_dir/Actor_XX/filename.wav

    Returns:
        X (np.ndarray), y (list of str emotion labels)
    """
    X, y = [], []
    files = glob.glob(os.path.join(data_dir, '**', '*.wav'), recursive=True)
    print(f"[RAVDESS] Found {len(files)} files in {data_dir}")

    for f in tqdm(files, desc="RAVDESS"):
        try:
            name = os.path.basename(f)
            parts = name.replace('.wav', '').split('-')
            emotion_code = parts[2]
            label = RAVDESS_EMOTIONS.get(emotion_code)
            if label is None:
                continue
            features = extract_features(audio_path=f)
            X.append(features)
            y.append(label)
        except Exception as e:
            print(f"[skip] {f}: {e}")

    return np.array(X), y


def load_cremad(data_dir: str):
    """
    Load CREMA-D dataset from flat directory of .wav files.
    Filename format: 1001_DFA_ANG_XX.wav

    Returns:
        X (np.ndarray), y (list of str emotion labels)
    """
    X, y = [], []
    files = glob.glob(os.path.join(data_dir, '*.wav'))
    print(f"[CREMA-D] Found {len(files)} files in {data_dir}")

    for f in tqdm(files, desc="CREMA-D"):
        try:
            name = os.path.basename(f)
            parts = name.split('_')
            emotion_code = parts[2]
            label = CREMAD_EMOTIONS.get(emotion_code)
            if label is None:
                continue
            features = extract_features(audio_path=f)
            X.append(features)
            y.append(label)
        except Exception as e:
            print(f"[skip] {f}: {e}")

    return np.array(X), y


def load_all(ravdess_dir=None, cremad_dir=None):
    """
    Load and combine RAVDESS and/or CREMA-D datasets.

    Returns:
        X (np.ndarray), y (list of str emotion labels)
    """
    all_X, all_y = [], []

    if ravdess_dir and os.path.isdir(ravdess_dir):
        X_r, y_r = load_ravdess(ravdess_dir)
        all_X.append(X_r)
        all_y.extend(y_r)
        print(f"[✓] RAVDESS loaded: {len(y_r)} samples")

    if cremad_dir and os.path.isdir(cremad_dir):
        X_c, y_c = load_cremad(cremad_dir)
        all_X.append(X_c)
        all_y.extend(y_c)
        print(f"[✓] CREMA-D loaded: {len(y_c)} samples")

    if not all_X:
        raise FileNotFoundError("No valid dataset directories found.")

    return np.vstack(all_X), all_y


def save_dataset(X, y, out_dir='data'):
    """Save processed feature matrix and labels to disk."""
    os.makedirs(out_dir, exist_ok=True)
    np.save(os.path.join(out_dir, 'X.npy'), X)
    np.save(os.path.join(out_dir, 'y.npy'), np.array(y))
    print(f"[✓] Dataset saved: X={X.shape}, y={len(y)} labels → {out_dir}/")


def load_dataset(data_dir='data'):
    """Load previously saved feature matrix and labels."""
    X = np.load(os.path.join(data_dir, 'X.npy'))
    y = list(np.load(os.path.join(data_dir, 'y.npy')))
    print(f"[✓] Dataset loaded: {X.shape[0]} samples, {X.shape[1]} features")
    return X, y
