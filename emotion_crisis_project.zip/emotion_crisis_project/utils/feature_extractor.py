"""
Feature Extractor — Emotion Sound Crisis Prediction System
Extracts MFCC, pitch, energy, ZCR, and chroma features from audio.
"""

import numpy as np
import librosa


def extract_features(audio_path=None, y=None, sr=22050, n_mfcc=40):
    """
    Extract a rich feature vector from an audio file or raw waveform.

    Args:
        audio_path (str): Path to .wav/.mp3 file (optional if y is given).
        y (np.ndarray): Raw audio waveform array (optional).
        sr (int): Sample rate.
        n_mfcc (int): Number of MFCC coefficients.

    Returns:
        np.ndarray: Feature vector of shape (193,)
    """
    if audio_path is not None:
        y, sr = librosa.load(audio_path, sr=sr, duration=3.0)

    if y is None:
        raise ValueError("Provide either audio_path or raw waveform y.")

    features = []

    # 1. MFCCs (40 coefficients × mean + std = 80 features)
    mfccs = librosa.feature.mfcc(y=y, sr=sr, n_mfcc=n_mfcc)
    features.extend(np.mean(mfccs, axis=1))
    features.extend(np.std(mfccs, axis=1))

    # 2. Chroma features (12 × mean + std = 24 features)
    chroma = librosa.feature.chroma_stft(y=y, sr=sr)
    features.extend(np.mean(chroma, axis=1))
    features.extend(np.std(chroma, axis=1))

    # 3. Mel spectrogram (128 × mean = 128 features) — only mean to save dims
    mel = librosa.feature.melspectrogram(y=y, sr=sr)
    features.extend(np.mean(mel, axis=1))

    # 4. Zero crossing rate (mean + std = 2 features)
    zcr = librosa.feature.zero_crossing_rate(y)
    features.append(np.mean(zcr))
    features.append(np.std(zcr))

    # 5. RMS energy (mean + std = 2 features)
    rms = librosa.feature.rms(y=y)
    features.append(np.mean(rms))
    features.append(np.std(rms))

    # 6. Spectral rolloff (mean + std = 2 features)
    rolloff = librosa.feature.spectral_rolloff(y=y, sr=sr)
    features.append(np.mean(rolloff))
    features.append(np.std(rolloff))

    # 7. Spectral centroid (mean + std = 2 features)
    centroid = librosa.feature.spectral_centroid(y=y, sr=sr)
    features.append(np.mean(centroid))
    features.append(np.std(centroid))

    return np.array(features, dtype=np.float32)


def extract_pitch(y, sr=22050):
    """Extract fundamental frequency (pitch) contour."""
    pitches, magnitudes = librosa.piptrack(y=y, sr=sr)
    pitch_values = []
    for t in range(pitches.shape[1]):
        index = magnitudes[:, t].argmax()
        pitch = pitches[index, t]
        if pitch > 0:
            pitch_values.append(pitch)
    return np.array(pitch_values) if pitch_values else np.array([0.0])


def speech_rate(y, sr=22050):
    """Estimate speech rate as syllables per second (proxy via ZCR bursts)."""
    zcr = librosa.feature.zero_crossing_rate(y, frame_length=2048, hop_length=512)[0]
    rate = np.sum(zcr > np.mean(zcr)) / (len(y) / sr)
    return float(rate)
