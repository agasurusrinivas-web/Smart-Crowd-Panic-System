# Emotion Sound Crisis Prediction System
