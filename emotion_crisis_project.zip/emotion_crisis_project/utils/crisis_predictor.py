"""
Crisis Predictor — Emotion Sound Crisis Prediction System
Maps detected emotions to a crisis probability score and triggers alerts.
"""

import time
import logging
from collections import deque
from models.emotion_model import EMOTION_CRISIS_WEIGHTS

logging.basicConfig(level=logging.INFO, format='[%(asctime)s] %(levelname)s: %(message)s')
logger = logging.getLogger(__name__)


CRISIS_THRESHOLD = 0.60      # score above this triggers a CRISIS alert
WARNING_THRESHOLD = 0.40     # score above this triggers a WARNING
WINDOW_SIZE = 5              # rolling window: last N predictions averaged


class CrisisPredictor:
    """
    Converts emotion predictions into a rolling crisis risk score.
    Uses a sliding window of recent emotion detections for smoothing.
    """

    def __init__(self, crisis_threshold=CRISIS_THRESHOLD, warning_threshold=WARNING_THRESHOLD):
        self.crisis_threshold = crisis_threshold
        self.warning_threshold = warning_threshold
        self.history = deque(maxlen=WINDOW_SIZE)
        self.alert_log = []

    def compute_score(self, emotion_label: str, confidence: float) -> float:
        """
        Compute instantaneous crisis score from a single prediction.

        Crisis score = base weight for emotion × model confidence
        """
        base_weight = EMOTION_CRISIS_WEIGHTS.get(emotion_label, 0.0)
        return round(base_weight * confidence, 4)

    def rolling_score(self, emotion_label: str, confidence: float) -> dict:
        """
        Update the rolling window and return comprehensive status dict.

        Returns:
            dict with keys: emotion, confidence, instant_score,
                            rolling_score, risk_level, alert_triggered
        """
        instant = self.compute_score(emotion_label, confidence)
        self.history.append(instant)

        avg_score = sum(self.history) / len(self.history)

        # Determine risk level
        if avg_score >= self.crisis_threshold:
            risk_level = "CRISIS"
            alert_triggered = True
        elif avg_score >= self.warning_threshold:
            risk_level = "WARNING"
            alert_triggered = True
        else:
            risk_level = "SAFE"
            alert_triggered = False

        result = {
            "timestamp": time.strftime("%Y-%m-%d %H:%M:%S"),
            "emotion": emotion_label,
            "confidence": round(confidence, 4),
            "instant_score": instant,
            "rolling_score": round(avg_score, 4),
            "risk_level": risk_level,
            "alert_triggered": alert_triggered,
        }

        if alert_triggered:
            self._log_alert(result)

        return result

    def _log_alert(self, result: dict):
        """Record the alert and log to console."""
        self.alert_log.append(result)
        msg = (f"[{result['risk_level']}] Emotion={result['emotion']} | "
               f"Score={result['rolling_score']} | Time={result['timestamp']}")
        if result['risk_level'] == "CRISIS":
            logger.critical(msg)
        else:
            logger.warning(msg)

    def reset(self):
        """Clear rolling window (use between sessions)."""
        self.history.clear()

    def get_alert_summary(self) -> list:
        """Return all alerts logged in this session."""
        return self.alert_log.copy()

    def export_log(self, path="alerts/alert_log.txt"):
        """Write alert log to file."""
        import os
        os.makedirs("alerts", exist_ok=True)
        with open(path, "a") as f:
            for entry in self.alert_log:
                f.write(str(entry) + "\n")
        logger.info(f"Alert log exported to {path}")
