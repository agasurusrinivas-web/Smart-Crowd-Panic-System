"""
Real-Time Audio Listener — Emotion Sound Crisis Prediction System
Captures live microphone input, extracts features, predicts emotion, and scores crisis risk.
"""

import numpy as np
import time

try:
    import pyaudio
    PYAUDIO_AVAILABLE = True
except ImportError:
    PYAUDIO_AVAILABLE = False
    print("[WARNING] PyAudio not installed. Real-time mode unavailable.")

import librosa
from utils.feature_extractor import extract_features
from utils.crisis_predictor import CrisisPredictor
from models.emotion_model import EmotionModel


# Audio config
SAMPLE_RATE = 22050
CHUNK_DURATION = 3       # seconds per analysis window
CHUNK_SIZE = int(SAMPLE_RATE * CHUNK_DURATION)
FORMAT = 'int16'
CHANNELS = 1


class RealTimeListener:
    """
    Streams microphone audio in chunks, runs emotion detection,
    and feeds results into the crisis predictor.
    """

    def __init__(self, model_path='models/emotion_model', verbose=True):
        self.verbose = verbose
        self.predictor = CrisisPredictor()
        self.model = EmotionModel()
        self.model.load(model_path)
        self._running = False

    def start(self, duration=60):
        """
        Begin real-time monitoring.

        Args:
            duration (int): Total seconds to monitor (0 = infinite until Ctrl+C)
        """
        if not PYAUDIO_AVAILABLE:
            print("[ERROR] PyAudio required for real-time mode. Install with: pip install pyaudio")
            return

        import pyaudio
        pa = pyaudio.PyAudio()
        stream = pa.open(
            format=pyaudio.paInt16,
            channels=CHANNELS,
            rate=SAMPLE_RATE,
            input=True,
            frames_per_buffer=CHUNK_SIZE
        )

        self._running = True
        print(f"\n[🎙] Real-time monitoring started. Duration: {duration}s (0=infinite)\n")
        start_time = time.time()

        try:
            while self._running:
                if duration > 0 and (time.time() - start_time) >= duration:
                    break

                # Read one chunk
                raw = stream.read(CHUNK_SIZE, exception_on_overflow=False)
                y = np.frombuffer(raw, dtype=np.int16).astype(np.float32) / 32768.0

                # Extract features and predict
                try:
                    features = extract_features(y=y, sr=SAMPLE_RATE)
                    emotion, confidence, probs = self.model.predict_emotion(features)
                    result = self.predictor.rolling_score(emotion, confidence)
                    self._display(result)
                except Exception as e:
                    if self.verbose:
                        print(f"[skip frame] {e}")

        except KeyboardInterrupt:
            print("\n[✋] Monitoring stopped by user.")
        finally:
            stream.stop_stream()
            stream.close()
            pa.terminate()
            self.predictor.export_log()
            self._print_summary()

    def stop(self):
        self._running = False

    def process_file(self, audio_path: str) -> dict:
        """
        Run crisis prediction on a single audio file.

        Returns:
            dict: Final result with emotion, scores, and risk level.
        """
        self.predictor.reset()
        features = extract_features(audio_path=audio_path, sr=SAMPLE_RATE)
        emotion, confidence, probs = self.model.predict_emotion(features)
        result = self.predictor.rolling_score(emotion, confidence)
        if self.verbose:
            self._display(result)
        return result

    def _display(self, result: dict):
        level_icons = {"SAFE": "🟢", "WARNING": "🟡", "CRISIS": "🔴"}
        icon = level_icons.get(result['risk_level'], "⚪")
        print(
            f"{icon} [{result['timestamp']}] "
            f"Emotion: {result['emotion']:10s} | "
            f"Confidence: {result['confidence']:.2f} | "
            f"Crisis Score: {result['rolling_score']:.3f} | "
            f"Status: {result['risk_level']}"
        )

    def _print_summary(self):
        alerts = self.predictor.get_alert_summary()
        print(f"\n--- Session Summary ---")
        print(f"Total alerts triggered: {len(alerts)}")
        crisis_count = sum(1 for a in alerts if a['risk_level'] == 'CRISIS')
        warn_count = sum(1 for a in alerts if a['risk_level'] == 'WARNING')
        print(f"  CRISIS: {crisis_count}  |  WARNING: {warn_count}")
        print("Alert log saved to alerts/alert_log.txt")
