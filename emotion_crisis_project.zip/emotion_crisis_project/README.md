# Emotion Sound Crisis Prediction System

A real-time Speech Emotion Recognition (SER) system that detects hidden emotional distress in voice and predicts mental health crisis risk.

---

## What This System Does

Listens to audio → detects emotion (fear, sadness, anger, etc.) → computes a crisis probability score → triggers an alert if the score exceeds a threshold.

---

## Project Structure

```
emotion_crisis_project/
├── main.py                     # CLI entry point
├── app.py                      # Flask web server & REST API
├── train.py                    # Model training script
├── requirements.txt
│
├── utils/
│   ├── feature_extractor.py    # MFCC, pitch, energy, ZCR extraction
│   ├── crisis_predictor.py     # Crisis scoring & alert engine
│   └── realtime_listener.py    # Microphone stream processor
│
├── models/
│   └── emotion_model.py        # Neural network model (TF/Keras or sklearn)
│
├── data/
│   └── dataset_loader.py       # RAVDESS + CREMA-D loaders
│
├── templates/
│   └── index.html              # Web dashboard UI
│
└── alerts/
    └── alert_log.txt           # Session alert log (auto-generated)
```

---

## Installation

```bash
pip install -r requirements.txt
```

For real-time audio (microphone mode):
```bash
# Linux
sudo apt-get install portaudio19-dev
pip install pyaudio

# Windows/Mac
pip install pyaudio
```

---

## Usage

### 1. Train the Model

With RAVDESS dataset:
```bash
python train.py --ravdess /path/to/RAVDESS
```

With both RAVDESS + CREMA-D:
```bash
python train.py --ravdess /path/to/RAVDESS --cremad /path/to/CREMA-D
```

Quick demo (synthetic data, no dataset needed):
```bash
python train.py
```

### 2. Run Demo (No Model Required)
```bash
python main.py --demo
```

### 3. Predict from Audio File
```bash
python main.py --file your_audio.wav
```

### 4. Real-Time Microphone Monitoring
```bash
python main.py --live --duration 120
```

### 5. Start Web Dashboard
```bash
python app.py
# Visit http://localhost:5000
```

---

## How It Works

1. **Audio Input** — file upload or live microphone stream
2. **Feature Extraction** — MFCCs (40 coefficients), chroma, mel spectrogram, ZCR, RMS energy, spectral rolloff
3. **Emotion Classification** — Dense neural network classifies into 8 emotions
4. **Crisis Scoring** — Each emotion has a crisis weight (fearful=0.9, sad=0.5, neutral=0.0)
5. **Rolling Window** — Averages last 5 predictions to smooth noise
6. **Alert Dispatch** — CRISIS (score ≥ 0.60) or WARNING (score ≥ 0.40) triggers a logged alert

---

## Emotions Detected

| Emotion   | Crisis Weight |
|-----------|--------------|
| neutral   | 0.0          |
| calm      | 0.0          |
| happy     | 0.0          |
| surprised | 0.2          |
| sad       | 0.5          |
| angry     | 0.4          |
| disgust   | 0.6          |
| fearful   | **0.9**      |

---

## REST API Endpoints

| Method | Endpoint        | Description                          |
|--------|-----------------|--------------------------------------|
| GET    | `/`             | Web dashboard                        |
| POST   | `/predict`      | Upload audio file → emotion + score  |
| POST   | `/predict_text` | Demo: send emotion JSON directly     |
| GET    | `/status`       | Session alert counts                 |
| GET    | `/alerts`       | All session alerts                   |
| POST   | `/reset`        | Clear rolling window                 |

---

## Datasets

- **RAVDESS** — https://zenodo.org/record/1188976
- **CREMA-D** — https://github.com/CheyneyComputerScience/CREMA-D

---

## Technologies Used

- Python 3.x
- librosa (audio analysis)
- TensorFlow / Keras (deep learning)
- scikit-learn (preprocessing, fallback MLP)
- Flask (web API)
- PyAudio (real-time audio)
- NumPy, Pandas, Matplotlib

---

## Innovation Highlights

1. Real-time paralinguistic analysis (live stream, not just files)
2. Crisis probability mapping layer (emotion → risk score)
3. Multi-feature fusion (MFCC + pitch + energy + ZCR + chroma)
4. Rolling window smoothing (reduces false positives)
5. Automated alert dispatch with timestamped logging
