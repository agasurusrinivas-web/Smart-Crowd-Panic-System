"""
Main Entry Point — Emotion Sound Crisis Prediction System

Usage:
    python main.py --file path/to/audio.wav       # predict from file
    python main.py --live                          # real-time mic monitoring
    python main.py --demo                          # demo with simulated emotions
"""

import argparse
import sys
import os
sys.path.insert(0, os.path.dirname(__file__))


def run_demo():
    """Quick demo using simulated emotion scores (no model required)."""
    from utils.crisis_predictor import CrisisPredictor
    import time

    print("\n=== DEMO MODE — Simulated Emotion Stream ===\n")
    predictor = CrisisPredictor()

    demo_sequence = [
        ('neutral',  0.88),
        ('calm',     0.79),
        ('sad',      0.70),
        ('fearful',  0.85),
        ('fearful',  0.92),
        ('sad',      0.80),
        ('fearful',  0.95),
        ('neutral',  0.60),
    ]

    for emotion, confidence in demo_sequence:
        result = predictor.rolling_score(emotion, confidence)
        level_icons = {"SAFE": "🟢", "WARNING": "🟡", "CRISIS": "🔴"}
        icon = level_icons.get(result['risk_level'], "⚪")
        print(f"{icon} Emotion: {emotion:10s} | Confidence: {confidence:.2f} | "
              f"Score: {result['rolling_score']:.3f} | {result['risk_level']}")
        time.sleep(0.4)

    print("\n--- Session Alerts ---")
    for alert in predictor.get_alert_summary():
        print(f"  [{alert['risk_level']}] {alert['timestamp']} — {alert['emotion']}")


def main():
    parser = argparse.ArgumentParser(description='Emotion Sound Crisis Prediction System')
    parser.add_argument('--file', type=str, help='Path to audio file for prediction')
    parser.add_argument('--live', action='store_true', help='Real-time microphone monitoring')
    parser.add_argument('--demo', action='store_true', help='Run demo without model/audio')
    parser.add_argument('--duration', type=int, default=60, help='Live monitoring duration (sec)')
    args = parser.parse_args()

    if args.demo:
        run_demo()

    elif args.file:
        from utils.realtime_listener import RealTimeListener
        print(f"\n[→] Analyzing: {args.file}")
        listener = RealTimeListener()
        result = listener.process_file(args.file)
        print(f"\n[Result] Emotion: {result['emotion']} | Risk: {result['risk_level']} | Score: {result['rolling_score']}")

    elif args.live:
        from utils.realtime_listener import RealTimeListener
        listener = RealTimeListener()
        listener.start(duration=args.duration)

    else:
        print("Emotion Sound Crisis Prediction System")
        print("Run with: --demo | --file <path> | --live")
        print("Or start the web server: python app.py")


if __name__ == '__main__':
    main()
