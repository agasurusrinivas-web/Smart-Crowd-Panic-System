"""
Train Script — Emotion Sound Crisis Prediction System
Run this script to extract features from datasets and train the emotion model.

Usage:
    python train.py --ravdess path/to/ravdess --cremad path/to/cremad
    python train.py --ravdess path/to/ravdess          # RAVDESS only
    python train.py --load_cached                       # use saved data/X.npy
"""

import argparse
import numpy as np
import sys
import os

sys.path.insert(0, os.path.dirname(__file__))

from data.dataset_loader import load_all, save_dataset, load_dataset
from models.emotion_model import EmotionModel


def parse_args():
    parser = argparse.ArgumentParser(description='Train emotion crisis prediction model')
    parser.add_argument('--ravdess', type=str, default=None, help='Path to RAVDESS dataset')
    parser.add_argument('--cremad', type=str, default=None, help='Path to CREMA-D dataset')
    parser.add_argument('--load_cached', action='store_true', help='Load cached data/X.npy instead')
    parser.add_argument('--epochs', type=int, default=100)
    parser.add_argument('--batch_size', type=int, default=32)
    parser.add_argument('--output', type=str, default='models/emotion_model')
    return parser.parse_args()


def main():
    args = parse_args()

    print("=" * 55)
    print("  Emotion Sound Crisis Prediction System — Trainer")
    print("=" * 55)

    # Load data
    if args.load_cached:
        print("\n[→] Loading cached dataset...")
        X, y = load_dataset('data')
    elif args.ravdess or args.cremad:
        print("\n[→] Extracting features from audio files...")
        X, y = load_all(ravdess_dir=args.ravdess, cremad_dir=args.cremad)
        save_dataset(X, y)
    else:
        print("\n[!] No dataset path given and --load_cached not set.")
        print("    Generating synthetic demo data for testing...")
        np.random.seed(42)
        X = np.random.randn(800, 193).astype(np.float32)
        emotions = ['neutral','calm','happy','sad','angry','fearful','disgust','surprised']
        y = [emotions[i % 8] for i in range(800)]

    print(f"\n[✓] Dataset: {len(y)} samples | Feature dim: {X.shape[1]}")

    # Build and train
    print("\n[→] Building model...")
    model = EmotionModel(input_dim=X.shape[1], n_classes=8)
    model.build()

    print(f"\n[→] Training for {args.epochs} epochs...")
    model.train(X, y, epochs=args.epochs, batch_size=args.batch_size)

    # Save
    model.save(args.output)
    print(f"\n[✓] Done! Model saved to {args.output}")
    print("    Run `python app.py` to start the web server.")


if __name__ == '__main__':
    main()
